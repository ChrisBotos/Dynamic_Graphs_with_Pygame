from dynamic_graphs_with_pygame.dyn_graphs import DynamicPygameGraphs

