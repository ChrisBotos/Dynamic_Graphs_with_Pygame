from dynamic_graphs_with_pygame.graphs import dynamic_pygame_graphs_class

