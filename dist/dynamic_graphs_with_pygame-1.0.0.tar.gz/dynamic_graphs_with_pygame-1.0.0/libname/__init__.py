from libname import dynamic_graphs_with_pygame

